// var age = 22;  
// let name = "james";  
// const PI = 3.14;  
// //alert("hello world"+"name"); // 这里更正了aler为alert  
// //document.write("hello world""+name+"你的年龄是:"+age");
// document.getElementById("show").innerHTML="hello world"
// console.log("hello world"+name+"你的年龄是:"+age);  
// console.log("666");


// var num1 = prompt("请输入第一个值:");  
//  num1 = parseInt(num1);

// var num2 = prompt("请输入第二个值:");
//  num2 = parseInt(num2);

// //var result = num1 + num2;

// //alert("结果是：" + result);
// //console.log("hello "+yourName+"!你好!");
// document.getElementById("show").innerHTML=num1+num2;
// function sum(){
//     var num1 = document.getElementById("input1").value;
//     console.log(num1);
//     var num2 = document.getElementById("input2").value;
//     console.log(num2);
//     var result = parseInt(num1) + parseInt(num2);
//     console.log(result);
//     alert("结果是：" + result);
//     document.getElementById("show").innerHTML=result;
// }

function sum() {
    let username = document.getElementById("input1").value;
    let password = document.getElementById("input2").value;

    if (username === "admin" && password === "123456") {
        alert("登录成功！");
        window.location.href = "界面.html";  // Replace with your target HTML page
    } else {
        alert("登录失败！");
    }
}

// alert("Hello, World!");
// function register() {
//     let email = document.getElementById("register-email").value;
//     let password = document.getElementById("register-password").value;
//     let confirmPassword = document.getElementById("register-confirm-password").value;

//     if (password === confirmPassword) {
//         // Implement registration logic here
//         alert("Registration successful!");
//         window.location.href = "index.html"; // Redirect to the login page
//     } else {
//         alert("Passwords do not match!");
//     }
// }
// JavaScript code to control audio playback and progress bar
let audio = document.getElementById('audio-preview');
let playButton = document.querySelector('.play-button');
let progressBar = document.getElementById('progress-bar');

let isPlaying = false;

function playPreview() {
    if (!isPlaying) {
        audio.play();
        playButton.innerHTML = '&#10074;&#10074;'; // Change button to pause icon
    } else {
        audio.pause();
        playButton.innerHTML = '&#9658;'; // Change button to play icon
    }
    isPlaying = !isPlaying;
}

function updateProgress() {
    let progress = (audio.currentTime / audio.duration) * 100;
    progressBar.style.width = progress + '%';
}

audio.addEventListener('timeupdate', updateProgress);

function playSong(songUrl, button) {
    audio.src = songUrl;
    playButton = button;
    playPreview();
}

// Reset progress bar when audio ends
audio.addEventListener('ended', function() {
    progressBar.style.width = '0%';
    playButton.innerHTML = '&#9658;'; // Reset button to play icon
    isPlaying = false;
});
